<?php

namespace App\Http\Controllers;

use App\Models\contrat;
use App\Http\Requests\StorecontratRequest;
use App\Http\Requests\UpdatecontratRequest;

class ContratController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StorecontratRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StorecontratRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\contrat  $contrat
     * @return \Illuminate\Http\Response
     */
    public function show(contrat $contrat)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\contrat  $contrat
     * @return \Illuminate\Http\Response
     */
    public function edit(contrat $contrat)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatecontratRequest  $request
     * @param  \App\Models\contrat  $contrat
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatecontratRequest $request, contrat $contrat)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\contrat  $contrat
     * @return \Illuminate\Http\Response
     */
    public function destroy(contrat $contrat)
    {
        //
    }
}
